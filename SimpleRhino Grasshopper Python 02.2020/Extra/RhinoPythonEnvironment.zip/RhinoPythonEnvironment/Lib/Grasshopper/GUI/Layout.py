# encoding: utf-8
# module Grasshopper.GUI.Layout calls itself Layout
# from Grasshopper, Version=1.0.0.20, Culture=neutral, PublicKeyToken=dda4f5ec2cd80803
# by generator 1.145
""" NamespaceTracker represent a CLS namespace. """
# no imports

# no functions
# classes

class GH_GenericLayout(object):
    # no doc
    @staticmethod
    def Horizontal_ByIndex(area, stack, expand):
        """ Horizontal_ByIndex(area: Rectangle, stack: List[Rectangle], expand: bool) -> List[Rectangle] """
        pass

    @staticmethod
    def Horizontal_ByPosition(area, stack, expand, radical=None):
        """
        Horizontal_ByPosition(area: Rectangle, stack: List[Rectangle], expand: bool, radical: int) -> List[Rectangle]
        Horizontal_ByPosition(area: Rectangle, stack: List[Rectangle], expand: bool) -> List[Rectangle]
        """
        pass

    @staticmethod
    def Vertical_ByIndex(area, stack, expand):
        """ Vertical_ByIndex(area: Rectangle, stack: List[Rectangle], expand: bool) -> List[Rectangle] """
        pass

    @staticmethod
    def Vertical_ByPosition(area, stack, expand, radical=None):
        """
        Vertical_ByPosition(area: Rectangle, stack: List[Rectangle], expand: bool, radical: int) -> List[Rectangle]
        Vertical_ByPosition(area: Rectangle, stack: List[Rectangle], expand: bool) -> List[Rectangle]
        """
        pass


