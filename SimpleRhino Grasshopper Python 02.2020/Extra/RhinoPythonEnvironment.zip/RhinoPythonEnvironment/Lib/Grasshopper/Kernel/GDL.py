# encoding: utf-8
# module Grasshopper.Kernel.GDL calls itself GDL
# from Grasshopper, Version=1.0.0.20, Culture=neutral, PublicKeyToken=dda4f5ec2cd80803
# by generator 1.145
""" NamespaceTracker represent a CLS namespace. """
# no imports

# no functions
# classes

class GH_GDLParser(object):
    # no doc
    @staticmethod
    def ParseGDL(lines, messages):
        """ ParseGDL(lines: Array[str]) -> (GH_Document, Array[str]) """
        pass


