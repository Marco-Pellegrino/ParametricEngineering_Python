# encoding: utf-8
# module Grasshopper.Kernel.Geometry.ConvexHull calls itself ConvexHull
# from Grasshopper, Version=1.0.0.20, Culture=neutral, PublicKeyToken=dda4f5ec2cd80803
# by generator 1.145
""" NamespaceTracker represent a CLS namespace. """
# no imports

# no functions
# classes

class Solver(object):
    # no doc
    @staticmethod
    def Compute(nodes, hull):
        """ Compute(nodes: Node2List, hull: List[int]) -> bool """
        pass

    @staticmethod
    def ComputeHull(*__args):
        """
        ComputeHull(pts: Node2List) -> Polyline
        ComputeHull(GH_pts: IEnumerable[GH_Point], plane: Plane) -> (Polyline, Plane)
        ComputeHull(GH_pts: IEnumerable[GH_Point]) -> Polyline
        """
        pass


